from typing import Dict

import pandas as pd
from polygon import RESTClient
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry


class POLYGON(RESTClient):
    def __init__(self, auth_key: str, timeout: int = None):
        super().__init__(auth_key)
        retry_strategy = Retry(
            total=10, backoff_factor=10, status_forcelist=[429, 500, 502, 503, 504]
        )
        adapter = HTTPAdapter(max_retries=retry_strategy)

    def _create_descr_map(
        self, filename: str = "c:/users/alexk/data/polygon_series.csv"
    ) -> Dict[str, str]:
        series = pd.read_csv(filename)
        descr_map = {}
        for idx, row in series.iterrows():
            descr_map[row["id"]] = row["title"]
        return descr_map

    def pull_observations(
        self,
        series_id: str,
        start_date: str,
        end_date: str,
        multiplier: int,
        timespan: str,
        ticker = None,
        options: bool = None,
    ) -> pd.DataFrame:

        resp = POLYGON.get_aggs(
            self,
            ticker=f"{series_id}",
            multiplier=multiplier,
            timespan=timespan,
            from_=start_date,
            to=end_date,
            limit=50000,
        )

        df = pd.DataFrame(resp)
        df["date"] = pd.to_datetime(df["timestamp"], unit="ms")
        df["series_id"] = f"{series_id}"

        if options:
            series_id = ticker
        resp = POLYGON.get_ticker_details(self, ticker=f"{series_id}")
        df["name"] = resp.name
        df["industry"] = resp.sic_description

        df = df[
            [
                "date",
                "series_id",
                "name",
                "industry",
                "open",
                "high",
                "low",
                "close",
                "volume",
                "vwap",
                "transactions",
            ]
        ]

        return df